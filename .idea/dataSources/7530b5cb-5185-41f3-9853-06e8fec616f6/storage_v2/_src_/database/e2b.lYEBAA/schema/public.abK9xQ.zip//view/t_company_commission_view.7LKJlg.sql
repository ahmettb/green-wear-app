create view t_company_commission_view(id, name, vkn, c_ref_descriptor, status, commission_count) as
SELECT c.id,
       c.name,
       c.vkn,
       c.c_ref_descriptor,
       c.status,
       (SELECT count(*) AS count
        FROM t_fc_commission_rates_view cr
        WHERE cr.company_id = c.id
          AND cr.status = 'A'::text) AS commission_count
FROM t_company c;

alter table t_company_commission_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_company_commission_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_company_commission_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_company_commission_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_company_commission_view to "enes.yilmaz";

