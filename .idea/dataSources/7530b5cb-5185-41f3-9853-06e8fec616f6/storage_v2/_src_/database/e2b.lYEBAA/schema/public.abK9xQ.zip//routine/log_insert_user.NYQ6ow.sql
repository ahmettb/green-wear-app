create function log_insert_user() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_user', now(), 'i', '*', 'email:'||COALESCE(NEW.email, '')||',fax:'||COALESCE(NEW.fax, '')||',gsm:'||COALESCE(NEW.gsm, '')||',name:'||COALESCE(NEW.name, '')||',surname:'||COALESCE(NEW.surname, '')||',tckn:'||COALESCE(NEW.tckn, '')||',telephone:'||COALESCE(NEW.telephone, '')||',is_gsm_authorized:'||CASE WHEN NEW.is_gsm_authorized THEN 't' ELSE 'f' END||',birthdate:'||COALESCE(NEW.birthdate::text, '')); 
	RETURN NEW;
END;
$$;

alter function log_insert_user() owner to fptest;

grant execute on function log_insert_user() to "akin.kemer";

grant execute on function log_insert_user() to "bilal.y";

grant execute on function log_insert_user() to "cem.sekem";

