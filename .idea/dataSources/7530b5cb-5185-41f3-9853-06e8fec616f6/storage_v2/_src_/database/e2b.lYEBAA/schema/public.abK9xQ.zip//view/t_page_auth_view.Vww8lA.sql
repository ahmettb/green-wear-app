create view t_page_auth_view(page_code, title, description, page_type, username, email) as
SELECT tp.page_code,
       tp.title,
       tp.description,
       tp.page_type,
       (tu.name::text || ' '::text) || tu.surname::text AS username,
       tu.email
FROM t_page tp,
     t_page_user tpu,
     t_user tu
WHERE tp.id = tpu.page_id
  AND tpu.user_id = tu.id
ORDER BY tp.page_code;

alter table t_page_auth_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_page_auth_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_page_auth_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_page_auth_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_page_auth_view to "enes.yilmaz";

