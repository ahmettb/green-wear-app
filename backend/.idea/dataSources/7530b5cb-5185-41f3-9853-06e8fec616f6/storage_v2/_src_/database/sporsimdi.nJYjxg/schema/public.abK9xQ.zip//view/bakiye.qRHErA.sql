create view bakiye(id, kasa_id, tarih, gider, gelir, bakiye) as
SELECT row_number() OVER (ORDER BY defter.kasa_id) AS id,
       defter.kasa_id,
       defter.tarih,
       sum(defter.gider)                           AS gider,
       sum(defter.gelir)                           AS gelir,
       sum(defter.gelir) - sum(defter.gider)       AS bakiye
FROM defter
WHERE defter.status = 1
GROUP BY defter.kasa_id, defter.tarih
ORDER BY defter.kasa_id, defter.tarih;

alter table bakiye
    owner to pgrootcmv;

