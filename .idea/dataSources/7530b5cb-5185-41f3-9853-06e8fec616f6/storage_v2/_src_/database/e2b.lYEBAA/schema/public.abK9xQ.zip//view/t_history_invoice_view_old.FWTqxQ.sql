create view t_history_invoice_view_old
            (n_order, row_num, row_desc, lead_descriptor, lag_time, id, user_id, kullanici, table_name, operation_time,
             operation_type, record_id, column_name, value_string, information, invoice_id)
as
SELECT CASE
           WHEN t.lag_time = t.operation_time THEN 0
           ELSE 1
           END AS n_order,
       t.row_num,
       t.row_desc,
       t.lead_descriptor,
       t.lag_time,
       t.id,
       t.user_id,
       t.kullanici,
       t.table_name,
       t.operation_time,
       t.operation_type,
       t.record_id,
       t.column_name,
       t.value_string,
       t.information,
       t.invoice_id
FROM (SELECT row_number() OVER (ORDER BY h.id)                                                         AS row_num,
             (h.id || '_'::text) || row_number() OVER (ORDER BY h.id)                                  AS row_desc,
             lag(h.operation_time) OVER (ORDER BY h.operation_time)                                    AS lag_time,
             (lead(h.id) OVER (ORDER BY h.id) || '_'::text) ||
             (row_number() OVER (ORDER BY h.id) + 1)                                                   AS lead_descriptor,
             h.id,
             h.user_id,
             h.kullanici,
             h.table_name,
             h.operation_time,
             h.operation_type,
             h.record_id,
             h.column_name,
             h.value_string,
             h.information,
             i.invoice_id
      FROM t_history_view h
               JOIN t_invoice i ON h.record_id = i.id
      WHERE h.table_name = 't_invoice'::text
      ORDER BY i.invoice_id, h.operation_time) t;

alter table t_history_invoice_view_old
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_history_invoice_view_old to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_history_invoice_view_old to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_history_invoice_view_old to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_history_invoice_view_old to "enes.yilmaz";

