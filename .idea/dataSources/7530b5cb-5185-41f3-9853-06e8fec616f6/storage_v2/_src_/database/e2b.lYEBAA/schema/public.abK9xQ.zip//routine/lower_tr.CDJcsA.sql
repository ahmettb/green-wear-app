create function lower_tr(character varying) returns character varying
    language plpgsql
as
$$
BEGIN
    RETURN LOWER(TRANSLATE($1,'ÇŞĞİIÜÖ','çşğiıüö'));
END;
$$;

alter function lower_tr(varchar) owner to "akin.kemer";

grant execute on function lower_tr(varchar) to "bilal.y";

