create function track_invoice_match_records() returns trigger
    language plpgsql
as
$$

DECLARE
parent_id_count bigint;
_parent_id bigint;
--amount numeric;
parent_amount numeric;
parent_company_id bigint;
child_company_id bigint;

BEGIN
 --select tiv.amount into amount from t_invoice_view tiv where tiv.id = NEW.matching_invoice_id;
 select tiv.amount into parent_amount from t_invoice_view tiv where tiv.id = NEW.invoice_id;
 /*
 BEGIN
	
    select id into parent_id from t_invoice_match_track where matching_invoice_id = NEW.invoice_id;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        parent_id := -10;
  END;
 */
 --select supplier_company_id into parent_company_id from t_invoice where id = NEW.matching_invoice_id;
 
 select count(*) into parent_id_count from t_invoice_match_track where matching_invoice_id = NEW.invoice_id; 
 
 select supplier_company_id into child_company_id from t_invoice where id = NEW.matching_invoice_id;
 IF child_company_id = NEW.company_id THEN
 	select customer_company_id into child_company_id from t_invoice where id = NEW.matching_invoice_id;
 END IF;
 
 IF parent_id_count = 0 THEN
 	
    select supplier_company_id into parent_company_id from t_invoice where id = NEW.invoice_id;
 
 	IF parent_company_id = NEW.company_id THEN
 		select customer_company_id into parent_company_id from t_invoice where id = NEW.invoice_id;
 	END IF;
    
 	INSERT INTO t_invoice_match_track(invoice_id,matching_invoice_id,company_id, opt_type, parent_id, amount)
 	VALUES(-1, NEW.invoice_id, parent_company_id, 1, -1, NEW.amount) returning id into _parent_id;
    --SELECT currval('persons_id_seq');
    --select id into parent_id from t_invoice_match_track where invoice_match_id = NEW.id;
    
 END IF;
 
 IF parent_id_count > 0 THEN
 	select id into _parent_id from t_invoice_match_track where matching_invoice_id = NEW.invoice_id;
    delete from t_invoice_match_track where invoice_id = NEW.invoice_id and matching_invoice_id = -1;
 END IF;   
 
 
 
 INSERT INTO t_invoice_match_track(invoice_match_id, invoice_id,matching_invoice_id,company_id, opt_type, parent_id, amount)
 VALUES(NEW.id,NEW.invoice_id, NEW.matching_invoice_id, NEW.company_id , 1, _parent_id, NEW.matching_amount);
 
 select id into _parent_id from t_invoice_match_track where invoice_match_id = NEW.id;
 
 INSERT INTO t_invoice_match_track( invoice_id,matching_invoice_id,company_id, opt_type, parent_id, amount)
 VALUES(NEW.matching_invoice_id, -1 , child_company_id , 0, _parent_id, NEW.matching_amount);
 
 
 RETURN NEW;
END;
$$;

alter function track_invoice_match_records() owner to fptest;

grant execute on function track_invoice_match_records() to "akin.kemer";

grant execute on function track_invoice_match_records() to "bilal.y";

grant execute on function track_invoice_match_records() to "cem.sekem";

