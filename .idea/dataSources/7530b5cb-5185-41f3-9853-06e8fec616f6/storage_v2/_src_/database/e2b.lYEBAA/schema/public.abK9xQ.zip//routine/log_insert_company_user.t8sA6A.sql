create function log_insert_company_user() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_company_user', now(), 'i', '*', 'company_id:'||COALESCE(NEW.company_id::text, '')||',user_id:'||COALESCE(NEW.user_id::text, '')||',is_authorized:'||CASE WHEN NEW.is_authorized THEN 't' ELSE 'f' END||',change_password:'||CASE WHEN NEW.change_password THEN 't' ELSE 'f' END||',email:'||COALESCE(NEW.email, '')||',ref_descriptor:'||COALESCE(NEW.ref_descriptor, '')||',customer_key:'||COALESCE(NEW.customer_key, ''));
 
	RETURN NEW;
END;
$$;

alter function log_insert_company_user() owner to fptest;

grant execute on function log_insert_company_user() to "akin.kemer";

grant execute on function log_insert_company_user() to "bilal.y";

grant execute on function log_insert_company_user() to "cem.sekem";

