create view t_invoice_paths_view
            (id, invoice_id, matching_invoice_id, company_id, parent_id, depth, path, company_path) as
WITH RECURSIVE t_invoice_match_track_cte(id, invoice_id, matching_invoice_id, company_id, parent_id, depth, path,
                                         company_path) AS (SELECT tn.id,
                                                                  tn.invoice_id,
                                                                  tn.matching_invoice_id,
                                                                  tn.company_id,
                                                                  tn.parent_id,
                                                                  1               AS depth,
                                                                  tn.id::text     AS path,
                                                                  comp.name::text AS company_path
                                                           FROM t_invoice_match_track tn,
                                                                t_company comp
                                                           WHERE tn.parent_id IS NULL
                                                              OR tn.parent_id = '-1'::integer AND tn.company_id = comp.id
                                                           UNION ALL
                                                           SELECT c.id,
                                                                  c.invoice_id,
                                                                  c.matching_invoice_id,
                                                                  c.company_id,
                                                                  c.parent_id,
                                                                  p.depth + 1 AS depth,
                                                                  (p.path || '->'::text) || c.id::text,
                                                                  (p.company_path || '->'::text) || comp.name::text
                                                           FROM t_invoice_match_track_cte p,
                                                                t_invoice_match_track c,
                                                                t_company comp
                                                           WHERE c.parent_id = p.id
                                                             AND c.company_id = comp.id)
SELECT n.id,
       n.invoice_id,
       n.matching_invoice_id,
       n.company_id,
       n.parent_id,
       n.depth,
       n.path,
       n.company_path
FROM t_invoice_match_track_cte n
ORDER BY n.id;

alter table t_invoice_paths_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_invoice_paths_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_paths_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_paths_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_paths_view to "enes.yilmaz";

