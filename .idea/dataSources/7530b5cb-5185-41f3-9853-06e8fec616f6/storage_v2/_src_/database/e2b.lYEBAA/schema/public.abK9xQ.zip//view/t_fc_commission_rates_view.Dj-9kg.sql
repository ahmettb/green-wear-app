create view t_fc_commission_rates_view
            (id, match_count, used_match_count, remaining_match_count, fc_ref_descriptor, company_id, ratio_type, ratio,
             start_date, end_date, priority, description, status)
as
SELECT t.id,
       t.match_count,
       t.used_match_count,
       t.match_count - t.used_match_count AS remaining_match_count,
       t.fc_ref_descriptor,
       t.company_id,
       t.ratio_type,
       t.ratio,
       t.start_date,
       t.end_date,
       t.priority,
       t.description,
       CASE
           WHEN t.status::text = 'C'::text THEN 'C'::text
           WHEN t.status::text = 'P'::text THEN 'P'::text
           WHEN (t.match_count - t.used_match_count) > 0 AND ('now'::text::date - t.start_date) >= 0 AND
                (t.end_date - 'now'::text::date) >= 0 THEN 'A'::text
           ELSE 'P'::text
           END                            AS status
FROM (SELECT r.id,
             r.fc_ref_descriptor,
             r.company_id,
             CASE
                 WHEN r.match_count = 0 THEN 1
                 ELSE r.match_count
                 END AS match_count,
             CASE
                 WHEN r.match_count = 0 THEN 0::bigint
                 ELSE COALESCE((SELECT sum(u.match_count) AS sum
                                FROM t_fc_commission_usage u
                                WHERE u.fc_commission_rate_id = r.id), 0::bigint)
                 END AS used_match_count,
             r.ratio_type,
             r.ratio,
             r.start_date,
             r.end_date,
             r.priority,
             r.description,
             r.status
      FROM t_fc_commission_rates r) t
ORDER BY (
             CASE
                 WHEN t.status::text = 'C'::text THEN 'C'::text
                 WHEN t.status::text = 'P'::text THEN 'P'::text
                 WHEN (t.match_count - t.used_match_count) > 0 AND ('now'::text::date - t.start_date) >= 0 AND
                      (t.end_date - 'now'::text::date) >= 0 THEN 'A'::text
                 ELSE 'P'::text
                 END), t.priority, t.fc_ref_descriptor;

alter table t_fc_commission_rates_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_fc_commission_rates_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_fc_commission_rates_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_fc_commission_rates_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_fc_commission_rates_view to "enes.yilmaz";

