create view t_batch_invoice_confirm_view
            (id, batch_number, invoice_id, issue_date, amount, amount_currency, supplier_company_name,
             customer_company_name, payment_due_date, status, status_code, opponent_email_address, valor,
             payment_reference_number)
as
SELECT ti.id,
       ti.batch_number,
       ti.invoice_id,
       ti.issue_date,
       tim.payable_amount                        AS amount,
       tim.payable_amount_currency_id            AS amount_currency,
       tps.name                                  AS supplier_company_name,
       tpc.name                                  AS customer_company_name,
       tipt.payment_due_date,
       ti.status,
       ti.status_code,
       ti.opponent_email_address,
       tipt.payment_due_date - 'now'::text::date AS valor,
       ti.payment_reference_number
FROM t_batch_invoice ti
         LEFT JOIN (SELECT tpsi.id,
                           tpsi.invoice_party_id,
                           tpsi.name,
                           tps_1.invoice_id,
                           tps_1.type
                    FROM t_batch_invoice_party tps_1,
                         t_batch_invoice_party_name tpsi
                    WHERE tpsi.invoice_party_id = tps_1.id
                      AND tps_1.type::text = 'ACCOUNTING_SUPPLIER'::text) tps ON tps.invoice_id = ti.id
         LEFT JOIN (SELECT tpsi.id,
                           tpsi.invoice_party_id,
                           tpsi.name,
                           tpc_1.invoice_id,
                           tpc_1.type
                    FROM t_batch_invoice_party tpc_1,
                         t_batch_invoice_party_name tpsi
                    WHERE tpsi.invoice_party_id = tpc_1.id
                      AND tpc_1.type::text = 'ACCOUNTING_CUSTOMER'::text) tpc ON tpc.invoice_id = ti.id
         LEFT JOIN t_batch_invoice_legal_monetary_total tim ON tim.invoice_id = ti.id
         LEFT JOIN t_batch_invoice_payment_terms tipt ON tipt.invoice_id = ti.id
WHERE ti.uuid::text <> '-1'::text;

alter table t_batch_invoice_confirm_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_batch_invoice_confirm_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_batch_invoice_confirm_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_batch_invoice_confirm_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_batch_invoice_confirm_view to "enes.yilmaz";

