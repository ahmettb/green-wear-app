create view t_balance_view
            (company_id, borc, borc_tutar, alacak, alacak_tutar, from_company, to_company, invoice_id, payment_due_date,
             stat, status, with_ref_invoice_id, ref_company_name)
as
SELECT result.company_id,
       result.borc,
       result.borc_tutar,
       result.alacak,
       result.alacak_tutar,
       result.from_company,
       result.to_company,
       result.invoice_id,
       (SELECT t_invoice_payment_terms.payment_due_date
        FROM t_invoice_payment_terms
        WHERE result.invoice_id = t_invoice_payment_terms.invoice_id) AS payment_due_date,
       result.stat,
       result.status,
       result.with_ref_invoice_id,
       result.ref_company_name
FROM (SELECT p.company_id,
             p.borc,
             p.borc_tutar,
             p.alacak,
             p.alacak_tutar,
             p.from_company,
             p.to_company,
             p.invoice_id,
             p.stat,
             p.status,
             p.with_ref_invoice_id,
             rtos.ref_company_name
      FROM (SELECT mt.company_id,
                   1                                                AS borc,
                   mt.amount                                        AS borc_tutar,
                   '-1'::integer                                    AS alacak,
                   0                                                AS alacak_tutar,
                   NULL::text                                       AS from_company,
                   mto.to_company_name                              AS to_company,
                   mto.invoice_id,
                   (SELECT t_invoice_match.status
                    FROM t_invoice_match
                    WHERE t_invoice_match.id = mt.invoice_match_id) AS stat,
                   'TEMLIK'::text                                   AS status,
                   mt.invoice_id                                    AS with_ref_invoice_id
            FROM t_invoice_match_track mt
                     LEFT JOIN (SELECT mtop.id,
                                       mtop.invoice_match_id,
                                       mtop.invoice_id,
                                       mtop.matching_invoice_id,
                                       mtop.company_id,
                                       mtop.opt_type,
                                       mtop.parent_id,
                                       mtop.amount,
                                       c.name AS to_company_name
                                FROM t_invoice_match_track mtop,
                                     t_company c
                                WHERE mtop.company_id = c.id) mto ON mt.matching_invoice_id = mto.invoice_id
            WHERE mt.opt_type = 1) p
               LEFT JOIN (SELECT mtos.matching_invoice_id,
                                 c.name AS ref_company_name
                          FROM t_invoice_match_track mtos,
                               t_company c
                          WHERE mtos.company_id = c.id) rtos ON p.with_ref_invoice_id = rtos.matching_invoice_id
      UNION
      SELECT r.company_id,
             r.borc,
             r.borc_tutar,
             r.alacak,
             r.alacak_tutar,
             r.from_company,
             r.to_company,
             r.invoice_id,
             r.stat,
             r.status,
             r.with_ref_invoice_id,
             paths.ref_company_name
      FROM (SELECT mt.company_id,
                   '-1'::integer           AS borc,
                   0                       AS borc_tutar,
                   1                       AS alacak,
                   mto.amount              AS alacak_tutar,
                   mto.to_company_name     AS from_company,
                   NULL::text              AS to_company,
                   mto.matching_invoice_id AS invoice_id,
                   ''::text                AS stat,
                   ''::text                AS status,
                   mto.invoice_id          AS with_ref_invoice_id
            FROM t_invoice_match_track mt
                     RIGHT JOIN (SELECT mtop.id,
                                        mtop.invoice_match_id,
                                        mtop.invoice_id,
                                        mtop.matching_invoice_id,
                                        mtop.company_id,
                                        mtop.opt_type,
                                        mtop.parent_id,
                                        mtop.amount,
                                        c.name AS to_company_name
                                 FROM t_invoice_match_track mtop,
                                      t_company c
                                 WHERE mtop.company_id = c.id) mto ON mt.invoice_id = mto.matching_invoice_id
            WHERE mt.opt_type = 1
            GROUP BY mt.company_id, '-1'::integer, 0::integer, 1::integer, mto.amount, mto.to_company_name, NULL::text,
                     mto.matching_invoice_id, ''::text, mto.invoice_id) r
               LEFT JOIN (SELECT "substring"(a.company_path, 0, strpos(a.company_path, '->'::text)) AS ref_company_name,
                                 a.invoice_id,
                                 a.matching_invoice_id
                          FROM t_invoice_paths_view a) paths
                         ON r.invoice_id = paths.matching_invoice_id AND r.with_ref_invoice_id = paths.invoice_id
      UNION
      SELECT t.company_id,
             t.borc,
             t.borc_tutar,
             t.alacak,
             t.alacak_tutar,
             t.from_company,
             t.to_company,
             t.invoice_id,
             t.stat,
             t.status,
             t.with_ref_invoice_id,
             paths.ref_company_name
      FROM (SELECT mt.company_id,
                   '-1'::integer           AS borc,
                   0                       AS borc_tutar,
                   1                       AS alacak,
                   mto.amount              AS alacak_tutar,
                   mto.to_company_name     AS from_company,
                   NULL::text              AS to_company,
                   mto.matching_invoice_id AS invoice_id,
                   ''::text                AS stat,
                   ''::text                AS status,
                   mto.invoice_id          AS with_ref_invoice_id
            FROM t_invoice_match_track mt
                     RIGHT JOIN (SELECT mtop.id,
                                        mtop.invoice_match_id,
                                        mtop.invoice_id,
                                        mtop.matching_invoice_id,
                                        mtop.company_id,
                                        mtop.opt_type,
                                        mtop.parent_id,
                                        mtop.amount,
                                        c.name AS to_company_name
                                 FROM t_invoice_match_track mtop,
                                      t_company c
                                 WHERE mtop.company_id = c.id) mto ON mt.invoice_id = mto.matching_invoice_id
            WHERE mt.opt_type = 0
              AND mt.matching_invoice_id = '-1'::integer
            GROUP BY mt.company_id, '-1'::integer, 0::integer, 1::integer, mto.amount, mto.to_company_name, NULL::text,
                     mto.matching_invoice_id, ''::text, mto.invoice_id) t
               LEFT JOIN (SELECT "substring"(a.company_path, 0, strpos(a.company_path, '->'::text)) AS ref_company_name,
                                 a.invoice_id,
                                 a.matching_invoice_id
                          FROM t_invoice_paths_view a) paths ON t.invoice_id = paths.matching_invoice_id AND
                                                                t.with_ref_invoice_id = paths.invoice_id) result
ORDER BY result.company_id, result.invoice_id;

alter table t_balance_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_balance_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_balance_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_balance_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_balance_view to "enes.yilmaz";

