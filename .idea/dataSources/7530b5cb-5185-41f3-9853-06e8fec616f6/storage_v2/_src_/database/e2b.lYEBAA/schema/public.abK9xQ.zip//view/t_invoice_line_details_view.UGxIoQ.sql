create view t_invoice_line_details_view(id, name, invoiced_quantity, tax_amount, total_amount) as
SELECT ti.id,
       tili.name,
       til.invoiced_quantity,
       tiltts.tax_amount,
       tim.payable_amount AS total_amount
FROM t_invoice ti
         LEFT JOIN t_invoice_line til ON ti.id = til.invoice_id
         LEFT JOIN t_invoice_line_item tili ON til.id = tili.invoice_line_id
         LEFT JOIN t_invoice_line_tax_total_subtotal tiltts ON tili.invoice_line_id = tiltts.invoice_line_tax_total_id
         LEFT JOIN t_invoice_legal_monetary_total tim ON tim.invoice_id = ti.id
WHERE ti.uuid::text <> '-1'::text;

alter table t_invoice_line_details_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_invoice_line_details_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_line_details_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_line_details_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_line_details_view to "enes.yilmaz";

