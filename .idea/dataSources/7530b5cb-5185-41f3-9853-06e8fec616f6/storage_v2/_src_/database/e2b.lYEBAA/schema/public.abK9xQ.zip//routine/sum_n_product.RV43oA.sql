create function sum_n_product(x bigint, y bigint, OUT sum bigint, OUT prod bigint) returns record
    language plpgsql
as
$$
BEGIN
    sum := x + y;
    prod := x * y;
END;
$$;

alter function sum_n_product(bigint, bigint, out bigint, out bigint) owner to fptest;

grant execute on function sum_n_product(bigint, bigint, out bigint, out bigint) to "akin.kemer";

grant execute on function sum_n_product(bigint, bigint, out bigint, out bigint) to "bilal.y";

grant execute on function sum_n_product(bigint, bigint, out bigint, out bigint) to "cem.sekem";

