create function log_update_invoice_match() returns trigger
    language plpgsql
as
$$
DECLARE
description VARCHAR(5000) := '';
column_names VARCHAR(500) := '';
BEGIN
   IF (OLD.status != NEW.status)
   then
	description := OLD.status || '->' || NEW.status;
	column_names := 'status';
   end if;

   IF (OLD.invoice_id != NEW.invoice_id)
   then
	description := description || '|' || COALESCE(OLD.invoice_id::text, '')|| '->' || COALESCE(NEW.invoice_id::text, '');
	column_names := column_names || '|invoice_id';
   end if;
   
   IF (OLD.matching_invoice_id != NEW.matching_invoice_id)
   then
	description := description || '|' || COALESCE(OLD.matching_invoice_id::text, '') || '->' || COALESCE(NEW.matching_invoice_id::text, '');
	column_names := column_names || '|matching_invoice_id';
   end if;

   IF (OLD.opponent_reject_reason != NEW.opponent_reject_reason)
   then
	description := description || '|' || COALESCE(OLD.opponent_reject_reason, '') || '->' || COALESCE(NEW.opponent_reject_reason, '');
	column_names := column_names || '|opponent_reject_reason';
   end if;

   IF (OLD.company_id != NEW.company_id)
   then
	description := description || '|' || COALESCE(OLD.company_id::text, '') || '->' || COALESCE(NEW.company_id::text, '');
	column_names := column_names || '|company_id';
   end if;

   if (description != '' and column_names != '')
   then
	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_invoice_match', now(), 'u', column_names, description);
   end if;
RETURN NEW;
END
$$;

alter function log_update_invoice_match() owner to fptest;

grant execute on function log_update_invoice_match() to "akin.kemer";

grant execute on function log_update_invoice_match() to "bilal.y";

grant execute on function log_update_invoice_match() to "cem.sekem";

