create view t_invoice_n_match_view
            (id, status, amount, matching_amount, confirms, borc_amount, borc_amount_currency, borc_inv_id,
             borc_invoice_id, borc_issue_date, borc_payment_due_date, borc_supplier_id, borc_supplier_name,
             borc_customer_id, borc_customer_name, alacak_amount, alacak_amount_currency, alacak_inv_id,
             alacak_invoice_id, alacak_issue_date, alacak_payment_due_date, alacak_supplier_id, alacak_supplier_name,
             alacak_customer_id, alacak_customer_name)
as
SELECT m.id,
       m.status,
       m.amount,
       m.matching_amount,
       mc.confirms,
       a.amount              AS borc_amount,
       a.amount_currency     AS borc_amount_currency,
       a.id                  AS borc_inv_id,
       a.invoice_id          AS borc_invoice_id,
       a.issue_date          AS borc_issue_date,
       a.payment_due_date    AS borc_payment_due_date,
       a.supplier_company_id AS borc_supplier_id,
       a.supplier_name       AS borc_supplier_name,
       a.customer_company_id AS borc_customer_id,
       a.customer_name       AS borc_customer_name,
       b.amount              AS alacak_amount,
       b.amount_currency     AS alacak_amount_currency,
       b.id                  AS alacak_inv_id,
       b.invoice_id          AS alacak_invoice_id,
       b.issue_date          AS alacak_issue_date,
       b.payment_due_date    AS alacak_payment_due_date,
       b.supplier_company_id AS alacak_supplier_id,
       b.supplier_name       AS alacak_supplier_name,
       b.customer_company_id AS alacak_customer_id,
       b.customer_name       AS alacak_customer_name
FROM t_invoice_match m
         LEFT JOIN (SELECT i.id,
                           i.invoice_id,
                           i.issue_date,
                           i.amount,
                           i.amount_currency,
                           i.supplier_company_id,
                           i.supplier_company_name,
                           i.customer_company_id,
                           i.customer_company_name,
                           i.payment_due_date,
                           i.status,
                           i.valor,
                           i.payment_reference_number,
                           c1.name AS supplier_name,
                           c2.name AS customer_name
                    FROM t_invoice_view i,
                         t_company c1,
                         t_company c2
                    WHERE i.supplier_company_id = c1.id
                      AND i.customer_company_id = c2.id) a ON m.invoice_id = a.id
         LEFT JOIN (SELECT i.id,
                           i.invoice_id,
                           i.issue_date,
                           i.amount,
                           i.amount_currency,
                           i.supplier_company_id,
                           i.supplier_company_name,
                           i.customer_company_id,
                           i.customer_company_name,
                           i.payment_due_date,
                           i.status,
                           i.valor,
                           i.payment_reference_number,
                           c1.name AS supplier_name,
                           c2.name AS customer_name
                    FROM t_invoice_view i,
                         t_company c1,
                         t_company c2
                    WHERE i.supplier_company_id = c1.id
                      AND i.customer_company_id = c2.id) b ON m.matching_invoice_id = b.id
         LEFT JOIN (SELECT t_invoice_match_confirmation.invoice_match_id,
                           string_agg(t_invoice_match_confirmation.company_id::text, ','::text) AS confirms
                    FROM t_invoice_match_confirmation
                    WHERE t_invoice_match_confirmation.confirmed = true
                    GROUP BY t_invoice_match_confirmation.invoice_match_id) mc ON mc.invoice_match_id = m.id
WHERE m.status::text = 'WAITING_CONFIRMATION'::text;

alter table t_invoice_n_match_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_invoice_n_match_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_n_match_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_n_match_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_n_match_view to "enes.yilmaz";

