create function log_update_company() returns trigger
    language plpgsql
as
$$
DECLARE
description text := '';
column_names text := '';
BEGIN
   IF (OLD.status != NEW.status)
   then
	description := COALESCE(OLD.status, '') || '->' || COALESCE(NEW.status, '');
	column_names := 'status';
   end if;

   IF (OLD.name != NEW.name)
   then
	description := description || '|' || COALESCE(OLD.name, '') || '->' || COALESCE(NEW.name, '');
	column_names := column_names || '|name';
   end if;
   
   IF (OLD.vkn != NEW.vkn)
   then
	description := description || '|' || COALESCE(OLD.vkn, '') || '->' || COALESCE(NEW.vkn, '');
	column_names := column_names || '|vkn';
   end if;

   IF (OLD.is_active != NEW.is_active)
   then
	description := description || '|' || CASE WHEN OLD.is_active THEN 't' ELSE 'f' END || '->' || CASE WHEN NEW.is_active THEN 't' ELSE 'f' END;
	column_names := column_names || '|is_active';
   end if;

   IF (OLD.email != NEW.email)
   then
	description := description || '|' || COALESCE(OLD.email, '') || '->' || COALESCE(NEW.email, '');
	column_names := column_names || '|email';
   end if;

   if (description != '' and column_names != '')
   then
	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_company', now(), 'u', column_names, description);
   end if;
RETURN NEW;
END
$$;

alter function log_update_company() owner to fptest;

grant execute on function log_update_company() to "akin.kemer";

grant execute on function log_update_company() to "bilal.y";

grant execute on function log_update_company() to "cem.sekem";

