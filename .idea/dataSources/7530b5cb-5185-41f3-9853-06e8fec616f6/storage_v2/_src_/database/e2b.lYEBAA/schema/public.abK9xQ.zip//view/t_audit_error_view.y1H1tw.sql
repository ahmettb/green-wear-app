create view t_audit_error_view
            (id, request_uri, request_ip, session_id, username, request_time, request_body, error_detail,
             method_signature, method_parameters)
as
SELECT ta.id,
       ta.request_uri,
       ta.request_ip,
       ta.session_id,
       (tu.name::text || ' '::text) || tu.surname::text AS username,
       ta.request_time,
       ta.request_body,
       ta.error_detail,
       ta.method_signature,
       ta.method_parameters
FROM t_audit_error_log ta
         LEFT JOIN t_user tu ON ta.user_id = tu.id;

alter table t_audit_error_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_audit_error_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_audit_error_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_audit_error_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_audit_error_view to "enes.yilmaz";

