create function upper_tr(character varying) returns character varying
    language plpgsql
as
$$
BEGIN
    RETURN UPPER(TRANSLATE($1,'ıi','Iİ'));
END;
$$;

alter function upper_tr(varchar) owner to pgrootcmv;

