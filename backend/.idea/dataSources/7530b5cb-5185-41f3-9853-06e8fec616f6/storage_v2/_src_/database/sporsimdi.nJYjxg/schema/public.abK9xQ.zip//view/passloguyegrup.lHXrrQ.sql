create view passloguyegrup
            (id, status, version, kisi_id, isletme_id, uyegrup_id, daycount, period, ratio, totalduration,
             averageduration) as
SELECT u.id,
       1               AS status,
       0               AS version,
       p.kisi_id,
       p.isletme_id,
       u.id            AS uyegrup_id,
       count(*)        AS daycount,
       CASE
           WHEN u.cikistarihi < 'now'::text::date THEN u.cikistarihi - u.giristarihi
           ELSE 'now'::text::date - u.giristarihi
           END         AS period,
       CASE
           WHEN u.cikistarihi < 'now'::text::date THEN count(*) * 100 / (u.cikistarihi - u.giristarihi)
           ELSE count(*) * 100 / ('now'::text::date - u.giristarihi)
           END         AS ratio,
       sum(p.duration) AS totalduration,
       avg(p.duration) AS averageduration
FROM passlogday p,
     uyegrup u,
     grup g,
     param pr
WHERE p.kisi_id = u.kisi_id
  AND p.day >= u.giristarihi
  AND p.day <= u.cikistarihi
  AND u.grup_id = g.id
  AND g.isletme_id = p.isletme_id
  AND pr.isletme_id = p.isletme_id
  AND pr.paramkey::text = 'DEVAM_YUZDE_SURE_EN_AZ'::text
  AND (p.duration / 60::double precision) > pr.paramvalue::double precision
GROUP BY u.id, p.kisi_id, p.isletme_id, u.giristarihi, u.cikistarihi;

alter table passloguyegrup
    owner to pgrootcmv;

