create view t_invoice_insurance_view
            (id, invoice_id, issue_date, customer_address, supplier_address, customer_email, supplier_email,
             customer_telephone, supplier_telephone, customer_fax, supplier_fax, customer_tax_office,
             supplier_tax_office, customer_vkn, supplier_vkn, supplier_contact_name, customer_contact_name,
             supplier_contact_email, customer_contact_email, supplier_contact_gsm, customer_contact_gsm, amount,
             amount_currency, supplier_company_id, supplier_company_name, customer_company_id, customer_company_name,
             payment_due_date, valor)
as
SELECT ti.id,
       ti.invoice_id,
       ti.issue_date,
       (SELECT (((((((tipa.street_name::text || ' No: '::text) || tipa.building_number::text) || ' '::text) ||
                   tipa.building_name::text) || ' '::text) || tipa.city_subdivision_name::text) || ' / '::text) ||
               tipa.city_name::text
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_address tipa ON tipa.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_CUSTOMER'::text) AS customer_address,
       (SELECT (((((((tipa.street_name::text || ' No: '::text) || tipa.building_number::text) || ' '::text) ||
                   tipa.building_name::text) || ' '::text) || tipa.city_subdivision_name::text) || ' / '::text) ||
               tipa.city_name::text
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_address tipa ON tipa.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_SUPPLIER'::text) AS supplier_address,
       (SELECT tipc.electronic_mail
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_contact tipc ON tipc.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_CUSTOMER'::text) AS customer_email,
       (SELECT tipc.electronic_mail
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_contact tipc ON tipc.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_SUPPLIER'::text) AS supplier_email,
       (SELECT tipc.telephone
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_contact tipc ON tipc.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_CUSTOMER'::text) AS customer_telephone,
       (SELECT tipc.telephone
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_contact tipc ON tipc.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_SUPPLIER'::text) AS supplier_telephone,
       (SELECT tipc.telefax
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_contact tipc ON tipc.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_CUSTOMER'::text) AS customer_fax,
       (SELECT tipc.telefax
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_contact tipc ON tipc.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_SUPPLIER'::text) AS supplier_fax,
       (SELECT tipts.tax_scheme_name
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_tax_scheme tipts ON tipts.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_CUSTOMER'::text) AS customer_tax_office,
       (SELECT tipts.tax_scheme_name
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_tax_scheme tipts ON tipts.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_SUPPLIER'::text) AS supplier_tax_office,
       (SELECT tipi.value
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_identification tipi ON tipi.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_CUSTOMER'::text
          AND tipi.scheme_id::text = 'VKN'::text)           AS customer_vkn,
       (SELECT tipi.value
        FROM t_invoice_party tip
                 LEFT JOIN t_invoice_party_identification tipi ON tipi.invoice_party_id = tip.id
        WHERE tip.invoice_id = ti.id
          AND tip.type::text = 'ACCOUNTING_SUPPLIER'::text
          AND tipi.scheme_id::text = 'VKN'::text)           AS supplier_vkn,
       (SELECT (u.name::text || ' '::text) || u.surname::text
        FROM t_user u
                 LEFT JOIN t_company_user cu ON u.id = cu.user_id
        WHERE cu.ref_descriptor::text ~~ '%|999-%'::text
          AND cu.company_id = tc1.id)                       AS supplier_contact_name,
       (SELECT (u.name::text || ' '::text) || u.surname::text
        FROM t_user u
                 LEFT JOIN t_company_user cu ON u.id = cu.user_id
        WHERE cu.ref_descriptor::text ~~ '%|999-%'::text
          AND cu.company_id = tc2.id)                       AS customer_contact_name,
       (SELECT u.email
        FROM t_user u
                 LEFT JOIN t_company_user cu ON u.id = cu.user_id
        WHERE cu.ref_descriptor::text ~~ '%|999-%'::text
          AND cu.company_id = tc1.id)                       AS supplier_contact_email,
       (SELECT u.email
        FROM t_user u
                 LEFT JOIN t_company_user cu ON u.id = cu.user_id
        WHERE cu.ref_descriptor::text ~~ '%|999-%'::text
          AND cu.company_id = tc2.id)                       AS customer_contact_email,
       (SELECT u.gsm
        FROM t_user u
                 LEFT JOIN t_company_user cu ON u.id = cu.user_id
        WHERE cu.ref_descriptor::text ~~ '%|999-%'::text
          AND cu.company_id = tc1.id)                       AS supplier_contact_gsm,
       (SELECT u.gsm
        FROM t_user u
                 LEFT JOIN t_company_user cu ON u.id = cu.user_id
        WHERE cu.ref_descriptor::text ~~ '%|999-%'::text
          AND cu.company_id = tc2.id)                       AS customer_contact_gsm,
       tim.payable_amount                                   AS amount,
       tim.payable_amount_currency_id                       AS amount_currency,
       ti.supplier_company_id,
       tc1.name                                             AS supplier_company_name,
       ti.customer_company_id,
       tc2.name                                             AS customer_company_name,
       tipt.payment_due_date,
       tipt.payment_due_date - 'now'::text::date            AS valor
FROM t_invoice ti
         LEFT JOIN t_company tc1 ON ti.supplier_company_id = tc1.id
         LEFT JOIN t_company tc2 ON ti.customer_company_id = tc2.id
         LEFT JOIN t_invoice_legal_monetary_total tim ON tim.invoice_id = ti.id
         LEFT JOIN t_invoice_payment_terms tipt ON tipt.invoice_id = ti.id
WHERE ti.uuid::text <> '-1'::text;

alter table t_invoice_insurance_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_invoice_insurance_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_insurance_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_insurance_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_insurance_view to "enes.yilmaz";

