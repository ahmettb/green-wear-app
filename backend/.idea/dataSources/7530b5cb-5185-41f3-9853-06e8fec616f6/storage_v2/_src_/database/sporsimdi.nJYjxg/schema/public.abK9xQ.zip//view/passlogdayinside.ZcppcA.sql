create view passlogdayinside (id, status, version, kisi_id, isletme_id, hall_id, day, logtime, duration) as
SELECT to_number(btrim(to_char(passlog.kisi_id, '999999999999999'::text)) || to_char(
        to_date(to_char(passlog.logtime, 'yyyyMMdd'::text), 'yyyyMMdd'::text)::timestamp with time zone,
        'yyyyMMdd'::text), '99999999999999999999999'::text)                             AS id,
       1                                                                                AS status,
       0                                                                                AS version,
       passlog.kisi_id,
       passlog.isletme_id,
       turnstile.hall_id,
       to_date(to_char(passlog.logtime, 'yyyyMMdd'::text), 'yyyyMMdd'::text)            AS day,
       min(passlog.logtime)                                                             AS logtime,
       date_part('epoch'::text, sum(now() - passlog.logtime::timestamp with time zone)) AS duration
FROM passlog,
     turnstile
WHERE passlog.turnstile_id = turnstile.id
  AND passlog.success = true
  AND (passlog.successout IS NULL OR passlog.successout IS FALSE)
GROUP BY passlog.kisi_id, passlog.isletme_id, turnstile.hall_id,
         (to_date(to_char(passlog.logtime, 'yyyyMMdd'::text), 'yyyyMMdd'::text));

alter table passlogdayinside
    owner to pgrootcmv;

