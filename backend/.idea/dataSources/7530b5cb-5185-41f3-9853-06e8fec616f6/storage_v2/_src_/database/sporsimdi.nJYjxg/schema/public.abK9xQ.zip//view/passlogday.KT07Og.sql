create view passlogday (id, status, version, kisi_id, isletme_id, day, logtime, logtimeout, duration, entrycount) as
SELECT to_number(btrim(to_char(passlog.kisi_id, '999999999999999'::text)) || to_char(
        to_date(to_char(passlog.logtime, 'yyyyMMdd'::text), 'yyyyMMdd'::text)::timestamp with time zone,
        'yyyyMMdd'::text), '99999999999999999999999'::text)                  AS id,
       1                                                                     AS status,
       0                                                                     AS version,
       passlog.kisi_id,
       passlog.isletme_id,
       to_date(to_char(passlog.logtime, 'yyyyMMdd'::text), 'yyyyMMdd'::text) AS day,
       min(passlog.logtime)                                                  AS logtime,
       max(passlog.logtimeout)                                               AS logtimeout,
       date_part('epoch'::text, sum(passlog.logtimeout - passlog.logtime))   AS duration,
       count(*)                                                              AS entrycount
FROM passlog
WHERE passlog.success = true
  AND passlog.successout = true
GROUP BY passlog.kisi_id, passlog.isletme_id, (to_date(to_char(passlog.logtime, 'yyyyMMdd'::text), 'yyyyMMdd'::text));

alter table passlogday
    owner to pgrootcmv;

