create function log_update_invoice() returns trigger
    language plpgsql
as
$$
DECLARE
description VARCHAR(5000) := '';
column_names VARCHAR(500) := '';
BEGIN
   IF (OLD.status != NEW.status)
   then
	description := COALESCE(OLD.status, '') || '->' || COALESCE(NEW.status, '');
	column_names := 'status';
   end if;

   IF (OLD.invoice_id != NEW.invoice_id)
   then
	description := description || '|' || COALESCE(OLD.invoice_id, '') || '->' || COALESCE(NEW.invoice_id, '');
	column_names := column_names || '|invoice_id';
   end if;
   
   IF (OLD.uuid != NEW.uuid)
   then
	description := description || '|' || COALESCE(NEW.uuid, '') || '->' || COALESCE(NEW.uuid, '');
	column_names := column_names || '|uuid';
   end if;

   IF (OLD.confirmed_by_uploader != NEW.confirmed_by_uploader)
   then
	description := description || '|' || CASE WHEN OLD.confirmed_by_uploader THEN 't' ELSE 'f' END || '->' || CASE WHEN NEW.confirmed_by_uploader THEN 't' ELSE 'f' END;
	column_names := column_names || '|confirmed_by_uploader';
   end if;

   IF (OLD.confirmed_by_opponent != NEW.confirmed_by_opponent)
   then
	description := description || '|' || CASE WHEN OLD.confirmed_by_opponent THEN 't' ELSE 'f' END || '->' || CASE WHEN NEW.confirmed_by_opponent THEN 't' ELSE 'f' END;
	column_names := column_names || '|confirmed_by_opponent';
   end if;

   if (description != '' and column_names != '')
   then
	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_invoice', now(), 'u', column_names, description);
   end if;
RETURN NEW;
END
$$;

alter function log_update_invoice() owner to fptest;

grant execute on function log_update_invoice() to "akin.kemer";

grant execute on function log_update_invoice() to "bilal.y";

grant execute on function log_update_invoice() to "cem.sekem";

