create function log_insert_company() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_company', now(), 'i', '*', 'email:'||COALESCE(NEW.email, '')||',name:'||COALESCE(NEW.name, '')||',telephone:'||COALESCE(NEW.telephone, '')||',vkn:'||COALESCE(NEW.vkn, '')||',is_active:'||CASE WHEN NEW.is_active THEN 't' ELSE 'f' END||',status:'||COALESCE(NEW.status, '')||',vkn_name:'||COALESCE(NEW.vkn_name, '')||',c_ref_descriptor:'||COALESCE(NEW.c_ref_descriptor, '')||',company_type:'||COALESCE(NEW.company_type, '')||',cfid:'||COALESCE(NEW.cfid, ''));
 
	RETURN NEW;
END;
$$;

alter function log_insert_company() owner to fptest;

grant execute on function log_insert_company() to "akin.kemer";

grant execute on function log_insert_company() to "bilal.y";

grant execute on function log_insert_company() to "cem.sekem";

