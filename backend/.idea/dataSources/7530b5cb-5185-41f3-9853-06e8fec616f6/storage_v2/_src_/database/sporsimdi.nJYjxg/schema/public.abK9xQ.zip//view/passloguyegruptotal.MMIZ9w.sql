create view passloguyegruptotal
            (id, status, version, kisi_id, isletme_id, daycount, period, ratio, totalduration, averageduration) as
SELECT passloguyegrup.kisi_id              AS id,
       1                                   AS status,
       0                                   AS version,
       passloguyegrup.kisi_id,
       passloguyegrup.isletme_id,
       sum(passloguyegrup.daycount)        AS daycount,
       sum(passloguyegrup.period)          AS period,
       avg(passloguyegrup.ratio)           AS ratio,
       sum(passloguyegrup.totalduration)   AS totalduration,
       avg(passloguyegrup.averageduration) AS averageduration
FROM passloguyegrup
GROUP BY passloguyegrup.kisi_id, passloguyegrup.isletme_id;

alter table passloguyegruptotal
    owner to pgrootcmv;

