create view aidathafta
            (rownum, isletme_id, kisi_id, isim, yilay, taksit_1, taksit_2, taksit_3, taksit_4, taksit_5, taksit_6,
             tahsil_1, tahsil_2, tahsil_3, tahsil_4, tahsil_5, tahsil_6, indirim_1, indirim_2, indirim_3, indirim_4,
             indirim_5, indirim_6)
as
SELECT row_number() OVER (ORDER BY y.isletme_id) AS rownum,
       y.isletme_id,
       y.kisi_id,
       y.isim,
       y.yilay,
       sum(y.taksit_1)                           AS taksit_1,
       sum(y.taksit_2)                           AS taksit_2,
       sum(y.taksit_3)                           AS taksit_3,
       sum(y.taksit_4)                           AS taksit_4,
       sum(y.taksit_5)                           AS taksit_5,
       sum(y.taksit_6)                           AS taksit_6,
       sum(COALESCE(y.tahsil_1, 0::numeric))     AS tahsil_1,
       sum(COALESCE(y.tahsil_2, 0::numeric))     AS tahsil_2,
       sum(COALESCE(y.tahsil_3, 0::numeric))     AS tahsil_3,
       sum(COALESCE(y.tahsil_4, 0::numeric))     AS tahsil_4,
       sum(COALESCE(y.tahsil_5, 0::numeric))     AS tahsil_5,
       sum(COALESCE(y.tahsil_6, 0::numeric))     AS tahsil_6,
       sum(COALESCE(y.indirim_1, 0::numeric))    AS indirim_1,
       sum(COALESCE(y.indirim_2, 0::numeric))    AS indirim_2,
       sum(COALESCE(y.indirim_3, 0::numeric))    AS indirim_3,
       sum(COALESCE(y.indirim_4, 0::numeric))    AS indirim_4,
       sum(COALESCE(y.indirim_5, 0::numeric))    AS indirim_5,
       sum(COALESCE(y.indirim_6, 0::numeric))    AS indirim_6
FROM (SELECT x.isletme_id,
             x.kisi_id,
             x.isim,
             x.yilay,
             CASE
                 WHEN x.hafta = 1::double precision THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_1,
             CASE
                 WHEN x.hafta = 2::double precision THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_2,
             CASE
                 WHEN x.hafta = 3::double precision THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_3,
             CASE
                 WHEN x.hafta = 4::double precision THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_4,
             CASE
                 WHEN x.hafta = 5::double precision THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_5,
             CASE
                 WHEN x.hafta = 6::double precision THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_6,
             CASE
                 WHEN x.hafta = 1::double precision THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_1,
             CASE
                 WHEN x.hafta = 2::double precision THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_2,
             CASE
                 WHEN x.hafta = 3::double precision THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_3,
             CASE
                 WHEN x.hafta = 4::double precision THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_4,
             CASE
                 WHEN x.hafta = 5::double precision THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_5,
             CASE
                 WHEN x.hafta = 6::double precision THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_6,
             CASE
                 WHEN x.hafta = 1::double precision THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_1,
             CASE
                 WHEN x.hafta = 2::double precision THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_2,
             CASE
                 WHEN x.hafta = 3::double precision THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_3,
             CASE
                 WHEN x.hafta = 4::double precision THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_4,
             CASE
                 WHEN x.hafta = 5::double precision THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_5,
             CASE
                 WHEN x.hafta = 6::double precision THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_6
      FROM (SELECT i.id                                                           AS isletme_id,
                   k.id                                                           AS kisi_id,
                   CASE
                       WHEN k.kisitipi::text = 'BIREYSEL'::text
                           THEN ((k.ad::text || ' '::text) || k.soyad::text)::character varying
                       ELSE k.unvan
                       END                                                        AS isim,
                   to_char(thkd.vadetarihi::timestamp with time zone, 'YYYY'::text) ||
                   to_char(thkd.vadetarihi::timestamp with time zone, 'MM'::text) AS yilay,
                   CASE
                       WHEN (date_part('week'::text, thkd.vadetarihi) - date_part('week'::text, to_date(
                               ((to_char(thkd.vadetarihi::timestamp with time zone, 'YYYY'::text) || '-'::text) ||
                                to_char(thkd.vadetarihi::timestamp with time zone, 'MM'::text)) || '-01'::text,
                               'YYYY-MM-DD'::text)) + 1::double precision) < 0::double precision
                           THEN date_part('week'::text, thkd.vadetarihi) + 1::double precision
                       ELSE date_part('week'::text, thkd.vadetarihi) - date_part('week'::text, to_date(
                               ((to_char(thkd.vadetarihi::timestamp with time zone, 'YYYY'::text) || '-'::text) ||
                                to_char(thkd.vadetarihi::timestamp with time zone, 'MM'::text)) || '-01'::text,
                               'YYYY-MM-DD'::text)) + 1::double precision
                       END                                                        AS hafta,
                   thkd.id,
                   max(COALESCE(thkd.taksittutari, 0::numeric))                   AS taksit,
                   sum(COALESCE(thsd.tahsiltutari, 0::numeric))                   AS tahsil,
                   sum(COALESCE(thsd.indirimtutari, 0::numeric))                  AS indirim
            FROM kisi k
                     JOIN kisiisletme ki ON k.id = ki.kisi_id AND ki.kisidurumu::text = 'UYE'::text
                     JOIN isletme i ON ki.isletme_id = i.id
                     LEFT JOIN uyegrup ug ON ug.kisi_id = k.id
                     LEFT JOIN tahakkuk thk ON thk.uyegrup_id = ug.id
                     LEFT JOIN tahakkukdetay thkd ON thkd.tahakkuk_id = thk.id
                     LEFT JOIN tahsilatdetay thsd ON thsd.tahakkukdetay_id = thkd.id
            GROUP BY i.id, k.id,
                     (
                         CASE
                             WHEN k.kisitipi::text = 'BIREYSEL'::text
                                 THEN ((k.ad::text || ' '::text) || k.soyad::text)::character varying
                             ELSE k.unvan
                             END),
                     (to_char(thkd.vadetarihi::timestamp with time zone, 'YYYY'::text) ||
                      to_char(thkd.vadetarihi::timestamp with time zone, 'MM'::text)),
                     (
                         CASE
                             WHEN (date_part('week'::text, thkd.vadetarihi) - date_part('week'::text, to_date(
                                     ((to_char(thkd.vadetarihi::timestamp with time zone, 'YYYY'::text) || '-'::text) ||
                                      to_char(thkd.vadetarihi::timestamp with time zone, 'MM'::text)) || '-01'::text,
                                     'YYYY-MM-DD'::text)) + 1::double precision) < 0::double precision
                                 THEN date_part('week'::text, thkd.vadetarihi) + 1::double precision
                             ELSE date_part('week'::text, thkd.vadetarihi) - date_part('week'::text, to_date(
                                     ((to_char(thkd.vadetarihi::timestamp with time zone, 'YYYY'::text) || '-'::text) ||
                                      to_char(thkd.vadetarihi::timestamp with time zone, 'MM'::text)) || '-01'::text,
                                     'YYYY-MM-DD'::text)) + 1::double precision
                             END), thkd.id) x
      GROUP BY x.isletme_id, x.kisi_id, x.isim, x.yilay, x.hafta) y
GROUP BY y.isletme_id, y.kisi_id, y.isim, y.yilay
ORDER BY y.kisi_id;

alter table aidathafta
    owner to pgrootcmv;

