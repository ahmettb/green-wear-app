create function sum_n_product(x integer, y integer, OUT sum integer, OUT prod integer) returns record
    language plpgsql
as
$$
BEGIN
    sum := x + y;
    prod := x * y;
END;
$$;

alter function sum_n_product(integer, integer, out integer, out integer) owner to fptest;

grant execute on function sum_n_product(integer, integer, out integer, out integer) to "akin.kemer";

grant execute on function sum_n_product(integer, integer, out integer, out integer) to "bilal.y";

grant execute on function sum_n_product(integer, integer, out integer, out integer) to "cem.sekem";

