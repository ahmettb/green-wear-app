create view t_invoice_view
            (id, invoice_id, issue_date, amount, amount_currency, supplier_company_id, supplier_company_name,
             customer_company_id, customer_company_name, payment_due_date, status, valor, payment_reference_number)
as
SELECT ti.id,
       ti.invoice_id,
       ti.issue_date,
       tim.payable_amount                        AS amount,
       tim.payable_amount_currency_id            AS amount_currency,
       ti.supplier_company_id,
       tc1.name                                  AS supplier_company_name,
       ti.customer_company_id,
       tc2.name                                  AS customer_company_name,
       tipt.payment_due_date,
       ti.status,
       tipt.payment_due_date - 'now'::text::date AS valor,
       ti.payment_reference_number
FROM t_invoice ti
         LEFT JOIN t_company tc1 ON ti.supplier_company_id = tc1.id
         LEFT JOIN t_company tc2 ON ti.customer_company_id = tc2.id
         LEFT JOIN t_invoice_legal_monetary_total tim ON tim.invoice_id = ti.id
         LEFT JOIN t_invoice_payment_terms tipt ON tipt.invoice_id = ti.id
WHERE ti.uuid::text <> '-1'::text;

alter table t_invoice_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_invoice_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_view to "enes.yilmaz";

