create function log_update_user() returns trigger
    language plpgsql
as
$$
DECLARE
description VARCHAR(5000) := '';
column_names VARCHAR(500) := '';
BEGIN
   IF (OLD.email != NEW.email)
   then
	description := COALESCE(OLD.email, '') || '->' || COALESCE(NEW.email, '');
	column_names := 'email';
   end if;

   IF (OLD.name != NEW.name)
   then
	description := description || '|' || COALESCE(OLD.name, '') || '->' || COALESCE(NEW.name, '');
	column_names := column_names || '|name';
   end if;
   
   IF (OLD.surname != NEW.surname)
   then
	description := description || '|' || COALESCE(OLD.surname, '') || '->' || COALESCE(NEW.surname, '');
	column_names := column_names || '|surname';
   end if;

   IF (OLD.tckn != NEW.tckn)
   then
	description := description || '|' || COALESCE(OLD.tckn, '') || '->' || COALESCE(NEW.tckn, '');
	column_names := column_names || '|tckn';
   end if;

   IF (OLD.is_gsm_authorized != NEW.is_gsm_authorized)
   then
	description := description || '|' || CASE WHEN OLD.is_gsm_authorized THEN 't' ELSE 'f' END || '->' || CASE WHEN NEW.is_gsm_authorized THEN 't' ELSE 'f' END;
	column_names := column_names || '|is_gsm_authorized';
   end if;

   if (description != '' and column_names != '')
   then
	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_user', now(), 'u', column_names, description);
   end if;
RETURN NEW;
END
$$;

alter function log_update_user() owner to fptest;

grant execute on function log_update_user() to "akin.kemer";

grant execute on function log_update_user() to "bilal.y";

grant execute on function log_update_user() to "cem.sekem";

