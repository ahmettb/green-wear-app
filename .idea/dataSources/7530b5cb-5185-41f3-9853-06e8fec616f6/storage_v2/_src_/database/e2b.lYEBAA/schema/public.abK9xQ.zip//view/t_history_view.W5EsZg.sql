create view t_history_view
            (id, user_id, kullanici, table_name, operation_time, operation_type, record_id, column_name, value_string,
             information) as
SELECT t1.id,
       t1.user_id,
       (u.name::text || ' '::text) || u.surname::text                         AS kullanici,
       t1.table_name,
       t1.operation_time,
       t1.operation_type,
       t1.record_id,
       t2.column_name,
       t1.value_string,
       ((((((((((u.name::text || ' '::text) || u.surname::text) || ' '::text) ||
              CASE
                  WHEN t1.table_name = 't_invoice'::text THEN 'Fatura'::text
                  WHEN t1.table_name = 't_invoice_match'::text THEN 'Fatura Eşleme'::text
                  WHEN t1.table_name = 't_company'::text THEN 'Firma'::text
                  WHEN t1.table_name = 't_user'::text THEN 'Kullanıcı'::text
                  WHEN t1.table_name = 't_company_user'::text THEN 'Login Bilgileri'::text
                  ELSE ''::text
                  END) || ' bilgilerinde '::text) || ttl.visible_lang_column_name::text) || ' değerini '::text) ||
          split_part(t1.value_string, '->'::text, 1)) || ' den '::text) ||
        split_part(t1.value_string, '->'::text, 2)) || ' ye değiştirdi'::text AS information
FROM (SELECT h.id,
             row_number() OVER (ORDER BY h.id) AS recid,
             h.user_id,
             h.table_name,
             h.operation_time,
             h.operation_type,
             h.record_id,
             t.value_string
      FROM t_history h,
           LATERAL unnest(string_to_array(h.description, '|'::text)) t(value_string)
      WHERE h.operation_type = 'u'::bpchar) t1,
     (SELECT h.id,
             row_number() OVER (ORDER BY h.id) AS recid,
             h.user_id,
             h.table_name,
             h.operation_time,
             h.operation_type,
             h.record_id,
             t.column_name
      FROM t_history h,
           LATERAL unnest(string_to_array(h.changed_columns, '|'::text)) t(column_name)
      WHERE h.operation_type = 'u'::bpchar) t2
         LEFT JOIN t_token_lang ttl ON t2.table_name = ttl.db_table_name::text AND t2.column_name = ttl.db_column_name::text
         LEFT JOIN t_user u ON t2.user_id = u.id
WHERE t1.id = t2.id
  AND t1.recid = t2.recid
  AND t2.column_name <> ''::text
  AND t1.value_string <> ''::text
UNION
SELECT h.id,
       h.user_id,
       (u.name::text || ' '::text) || u.surname::text                                       AS kullanici,
       h.table_name,
       h.operation_time,
       h.operation_type,
       h.record_id,
       h.changed_columns                                                                    AS column_name,
       h.description                                                                        AS value_string,
       (((((u.name::text || ' '::text) || u.surname::text) || ' tarafından '::text) ||
         CASE
             WHEN h.table_name = 't_invoice'::text THEN 'Fatura'::text
             WHEN h.table_name = 't_invoice_match'::text THEN 'Fatura Eşleme'::text
             WHEN h.table_name = 't_company'::text THEN 'Firma'::text
             WHEN h.table_name = 't_user'::text THEN 'Kullanıcı'::text
             WHEN h.table_name = 't_company_user'::text THEN 'Login Bilgileri'::text
             ELSE ''::text
             END) || ' bilgilerine yeni ekleme yapıldı. Değerler: '::text) || h.description AS information
FROM t_history h
         LEFT JOIN t_user u ON h.user_id = u.id
WHERE h.operation_type = 'i'::bpchar;

alter table t_history_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_history_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_history_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_history_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_history_view to "enes.yilmaz";

