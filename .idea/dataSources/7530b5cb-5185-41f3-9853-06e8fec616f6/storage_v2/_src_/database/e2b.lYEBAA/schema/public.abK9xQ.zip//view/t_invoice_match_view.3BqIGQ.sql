create view t_invoice_match_view
            (id, invoice_id, matching_invoice_id, match_status, opponent_reject_reason, amount, amount_currency,
             matching_amount, matching_amount_currency, new_matching_supplier_company_id,
             new_matching_supplier_company_name, new_matching_customer_company_id, new_matching_customer_company_name,
             new_supplier_company_id, new_supplier_company_name, new_customer_company_id, new_customer_company_name,
             company_id)
as
SELECT tim.id,
       tim.invoice_id,
       tim.matching_invoice_id,
       tim.status                AS match_status,
       tim.opponent_reject_reason,
       ti2.amount,
       ti2.amount_currency,
       ti1.amount                AS matching_amount,
       ti1.amount_currency       AS matching_amount_currency,
       ti1.supplier_company_id   AS new_matching_supplier_company_id,
       ti1.supplier_company_name AS new_matching_supplier_company_name,
       ti1.customer_company_id   AS new_matching_customer_company_id,
       ti1.customer_company_name AS new_matching_customer_company_name,
       ti2.supplier_company_id   AS new_supplier_company_id,
       ti2.supplier_company_name AS new_supplier_company_name,
       ti2.customer_company_id   AS new_customer_company_id,
       ti2.customer_company_name AS new_customer_company_name,
       tim.company_id
FROM t_invoice_view ti2,
     t_invoice_view ti1,
     t_invoice_match tim
WHERE tim.invoice_id = ti2.id
  AND tim.matching_invoice_id = ti1.id;

alter table t_invoice_match_view
    owner to fptest;

grant delete, insert, references, select, trigger, truncate, update on t_invoice_match_view to "akin.kemer";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_match_view to "bilal.y";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_match_view to "cem.sekem";

grant delete, insert, references, select, trigger, truncate, update on t_invoice_match_view to "enes.yilmaz";

