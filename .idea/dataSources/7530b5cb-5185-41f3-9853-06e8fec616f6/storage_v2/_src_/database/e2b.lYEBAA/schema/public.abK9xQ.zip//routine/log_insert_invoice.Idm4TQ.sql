create function log_insert_invoice() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_invoice', now(), 'i', '*', 'ubl_version_id:'||COALESCE(NEW.ubl_version_id, '')||',customization_id:'||COALESCE(NEW.customization_id, '')||',profile_id:'||COALESCE(NEW.profile_id, '')||',invoice_id:'||COALESCE(NEW.invoice_id, '')||',copy_indicator:'||CASE WHEN NEW.copy_indicator THEN 't' ELSE 'f' END||',uuid:'||COALESCE(NEW.uuid, '')||',issue_date:'||COALESCE(NEW.issue_date::text, '')||',invoice_type_code:'||COALESCE(NEW.invoice_type_code, '')||',line_count_numeric:'||COALESCE(NEW.line_count_numeric::text, '')||',confirmed_by_uploader:'||CASE WHEN NEW.confirmed_by_uploader THEN 't' ELSE 'f' END||',uploader_company_id:'||COALESCE(NEW.uploader_company_id::text, '')||',user_id:'||COALESCE(NEW.user_id::text, '')||',file_path:'||COALESCE(NEW.file_path, '')||',supplier_company_id:'||COALESCE(NEW.supplier_company_id::text, '')||',customer_company_id:'||COALESCE(NEW.customer_company_id::text, '')||',confirmed_by_opponent:'||CASE WHEN NEW.confirmed_by_opponent THEN 't' ELSE 'f' END||',opponent_rejection_reason:'||COALESCE(NEW.opponent_rejection_reason, '')||',status:'||COALESCE(NEW.status, '')||',payment_reference_number:'||COALESCE(NEW.payment_reference_number, ''));
	
	--INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_invoice', now(), 'i', '*', 'ubl_version_id:'||NEW.ubl_version_id||',customization_id:'||NEW.customization_id||',profile_id:'||NEW.profile_id||',invoice_id:'||NEW.invoice_id||',copy_indicator:'||NEW.copy_indicator||',uuid:'||NEW.uuid||',issue_date:'||NEW.issue_date||',invoice_type_code:'||NEW.invoice_type_code||',line_count_numeric:'||NEW.line_count_numeric||',confirmed_by_uploader:'||NEW.confirmed_by_uploader||',uploader_company_id:'||NEW.uploader_company_id||',user_id:'||NEW.user_id||',file_path:'||NEW.file_path||',supplier_company_id:'||NEW.supplier_company_id||',customer_company_id:'||NEW.customer_company_id||',confirmed_by_opponent:'||NEW.confirmed_by_opponent||',opponent_rejection_reason:'||NEW.opponent_rejection_reason||',status:'||NEW.status||',payment_reference_number:'||NEW.payment_reference_number);
 
	RETURN NEW;
END;
$$;

alter function log_insert_invoice() owner to fptest;

grant execute on function log_insert_invoice() to "akin.kemer";

grant execute on function log_insert_invoice() to "bilal.y";

grant execute on function log_insert_invoice() to "cem.sekem";

