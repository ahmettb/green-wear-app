create function log_insert_invoice_match() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
 	INSERT INTO public.t_history(record_id, user_id, table_name, operation_time, operation_type, changed_columns, description) VALUES (NEW.id, NEW.event_user_id, 't_invoice_match', now(), 'i', '*', 'invoice_id:'||COALESCE(NEW.invoice_id::text, '')||',matching_invoice_id:'||COALESCE(NEW.matching_invoice_id::text, '')||',status:'||COALESCE(NEW.status, '')||',opponent_reject_reason:'||COALESCE(NEW.opponent_reject_reason, '')||',user_id:'||COALESCE(NEW.user_id::text, '')||',company_id:'||COALESCE(NEW.company_id::text, ''));
	RETURN NEW;
END;
$$;

alter function log_insert_invoice_match() owner to fptest;

grant execute on function log_insert_invoice_match() to "akin.kemer";

grant execute on function log_insert_invoice_match() to "bilal.y";

grant execute on function log_insert_invoice_match() to "cem.sekem";

