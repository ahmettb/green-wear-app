create view aidatay
            (rownum, isletme_id, kisi_id, isim, yil, taksit_1, taksit_2, taksit_3, taksit_4, taksit_5, taksit_6,
             taksit_7, taksit_8, taksit_9, taksit_10, taksit_11, taksit_12, tahsil_1, tahsil_2, tahsil_3, tahsil_4,
             tahsil_5, tahsil_6, tahsil_7, tahsil_8, tahsil_9, tahsil_10, tahsil_11, tahsil_12, indirim_1, indirim_2,
             indirim_3, indirim_4, indirim_5, indirim_6, indirim_7, indirim_8, indirim_9, indirim_10, indirim_11,
             indirim_12)
as
SELECT row_number() OVER (ORDER BY y.isletme_id) AS rownum,
       y.isletme_id,
       y.kisi_id,
       y.isim,
       y.yil,
       sum(y.taksit_1)                           AS taksit_1,
       sum(y.taksit_2)                           AS taksit_2,
       sum(y.taksit_3)                           AS taksit_3,
       sum(y.taksit_4)                           AS taksit_4,
       sum(y.taksit_5)                           AS taksit_5,
       sum(y.taksit_6)                           AS taksit_6,
       sum(y.taksit_7)                           AS taksit_7,
       sum(y.taksit_8)                           AS taksit_8,
       sum(y.taksit_9)                           AS taksit_9,
       sum(y.taksit_10)                          AS taksit_10,
       sum(y.taksit_11)                          AS taksit_11,
       sum(y.taksit_12)                          AS taksit_12,
       sum(COALESCE(y.tahsil_1, 0::numeric))     AS tahsil_1,
       sum(COALESCE(y.tahsil_2, 0::numeric))     AS tahsil_2,
       sum(COALESCE(y.tahsil_3, 0::numeric))     AS tahsil_3,
       sum(COALESCE(y.tahsil_4, 0::numeric))     AS tahsil_4,
       sum(COALESCE(y.tahsil_5, 0::numeric))     AS tahsil_5,
       sum(COALESCE(y.tahsil_6, 0::numeric))     AS tahsil_6,
       sum(COALESCE(y.tahsil_7, 0::numeric))     AS tahsil_7,
       sum(COALESCE(y.tahsil_8, 0::numeric))     AS tahsil_8,
       sum(COALESCE(y.tahsil_9, 0::numeric))     AS tahsil_9,
       sum(COALESCE(y.tahsil_10, 0::numeric))    AS tahsil_10,
       sum(COALESCE(y.tahsil_11, 0::numeric))    AS tahsil_11,
       sum(COALESCE(y.tahsil_12, 0::numeric))    AS tahsil_12,
       sum(COALESCE(y.indirim_1, 0::numeric))    AS indirim_1,
       sum(COALESCE(y.indirim_2, 0::numeric))    AS indirim_2,
       sum(COALESCE(y.indirim_3, 0::numeric))    AS indirim_3,
       sum(COALESCE(y.indirim_4, 0::numeric))    AS indirim_4,
       sum(COALESCE(y.indirim_5, 0::numeric))    AS indirim_5,
       sum(COALESCE(y.indirim_6, 0::numeric))    AS indirim_6,
       sum(COALESCE(y.indirim_7, 0::numeric))    AS indirim_7,
       sum(COALESCE(y.indirim_8, 0::numeric))    AS indirim_8,
       sum(COALESCE(y.indirim_9, 0::numeric))    AS indirim_9,
       sum(COALESCE(y.indirim_10, 0::numeric))   AS indirim_10,
       sum(COALESCE(y.indirim_11, 0::numeric))   AS indirim_11,
       sum(COALESCE(y.indirim_12, 0::numeric))   AS indirim_12
FROM (SELECT x.isletme_id,
             x.kisi_id,
             x.isim,
             x.yil,
             CASE
                 WHEN x.ay = '01'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_1,
             CASE
                 WHEN x.ay = '02'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_2,
             CASE
                 WHEN x.ay = '03'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_3,
             CASE
                 WHEN x.ay = '04'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_4,
             CASE
                 WHEN x.ay = '05'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_5,
             CASE
                 WHEN x.ay = '06'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_6,
             CASE
                 WHEN x.ay = '07'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_7,
             CASE
                 WHEN x.ay = '08'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_8,
             CASE
                 WHEN x.ay = '09'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_9,
             CASE
                 WHEN x.ay = '10'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_10,
             CASE
                 WHEN x.ay = '11'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_11,
             CASE
                 WHEN x.ay = '12'::text THEN sum(x.taksit)
                 ELSE 0::numeric
                 END AS taksit_12,
             CASE
                 WHEN x.ay = '01'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_1,
             CASE
                 WHEN x.ay = '02'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_2,
             CASE
                 WHEN x.ay = '03'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_3,
             CASE
                 WHEN x.ay = '04'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_4,
             CASE
                 WHEN x.ay = '05'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_5,
             CASE
                 WHEN x.ay = '06'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_6,
             CASE
                 WHEN x.ay = '07'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_7,
             CASE
                 WHEN x.ay = '08'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_8,
             CASE
                 WHEN x.ay = '09'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_9,
             CASE
                 WHEN x.ay = '10'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_10,
             CASE
                 WHEN x.ay = '11'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_11,
             CASE
                 WHEN x.ay = '12'::text THEN sum(x.tahsil)
                 ELSE 0::numeric
                 END AS tahsil_12,
             CASE
                 WHEN x.ay = '01'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_1,
             CASE
                 WHEN x.ay = '02'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_2,
             CASE
                 WHEN x.ay = '03'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_3,
             CASE
                 WHEN x.ay = '04'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_4,
             CASE
                 WHEN x.ay = '05'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_5,
             CASE
                 WHEN x.ay = '06'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_6,
             CASE
                 WHEN x.ay = '07'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_7,
             CASE
                 WHEN x.ay = '08'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_8,
             CASE
                 WHEN x.ay = '09'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_9,
             CASE
                 WHEN x.ay = '10'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_10,
             CASE
                 WHEN x.ay = '11'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_11,
             CASE
                 WHEN x.ay = '12'::text THEN sum(x.indirim)
                 ELSE 0::numeric
                 END AS indirim_12
      FROM (SELECT i.id                                                             AS isletme_id,
                   k.id                                                             AS kisi_id,
                   CASE
                       WHEN k.kisitipi::text = 'BIREYSEL'::text
                           THEN ((k.ad::text || ' '::text) || k.soyad::text)::character varying
                       ELSE k.unvan
                       END                                                          AS isim,
                   to_char(thkd.vadetarihi::timestamp with time zone, 'YYYY'::text) AS yil,
                   to_char(thkd.vadetarihi::timestamp with time zone, 'MM'::text)   AS ay,
                   thkd.id,
                   max(COALESCE(thkd.taksittutari, 0::numeric))                     AS taksit,
                   sum(COALESCE(thsd.tahsiltutari, 0::numeric))                     AS tahsil,
                   sum(COALESCE(thsd.indirimtutari, 0::numeric))                    AS indirim
            FROM kisi k
                     JOIN kisiisletme ki ON k.id = ki.kisi_id AND ki.kisidurumu::text = 'UYE'::text
                     JOIN isletme i ON ki.isletme_id = i.id
                     LEFT JOIN uyegrup ug ON ug.kisi_id = k.id
                     LEFT JOIN tahakkuk thk ON thk.uyegrup_id = ug.id
                     LEFT JOIN tahakkukdetay thkd ON thkd.tahakkuk_id = thk.id
                     LEFT JOIN tahsilatdetay thsd ON thsd.tahakkukdetay_id = thkd.id
            GROUP BY i.id, k.id,
                     (
                         CASE
                             WHEN k.kisitipi::text = 'BIREYSEL'::text
                                 THEN ((k.ad::text || ' '::text) || k.soyad::text)::character varying
                             ELSE k.unvan
                             END), (to_char(thkd.vadetarihi::timestamp with time zone, 'YYYY'::text)),
                     (to_char(thkd.vadetarihi::timestamp with time zone, 'MM'::text)), thkd.id) x
      GROUP BY x.isletme_id, x.kisi_id, x.isim, x.yil, x.ay) y
GROUP BY y.isletme_id, y.kisi_id, y.isim, y.yil
ORDER BY y.kisi_id;

alter table aidatay
    owner to pgrootcmv;

