create view passloghall(id, status, version, isletme_id, hall_id, day, entrycount, duration) as
SELECT to_number(btrim(to_char(x.isletme_id, '09999999'::text)) ||
                 btrim(to_char(row_number() OVER (ORDER BY x.isletme_id, x.hall_id), '09999999999'::text)),
                 '99999999999999999999999'::text) AS id,
       1                                          AS status,
       0                                          AS version,
       x.isletme_id,
       x.hall_id,
       x.day,
       count(*)                                   AS entrycount,
       avg(x.duration)                            AS duration
FROM (SELECT passlog.kisi_id,
             passlog.isletme_id,
             turnstile.hall_id,
             to_date(to_char(passlog.logtime, 'yyyyMMdd'::text), 'yyyyMMdd'::text)                      AS day,
             min(passlog.logtime)                                                                       AS logtime,
             max(passlog.logtimeout)                                                                    AS logtimeout,
             date_part('epoch'::text, sum(passlog.logtimeout - passlog.logtime)) / 60::double precision AS duration,
             count(*)                                                                                   AS entrycount
      FROM passlog,
           turnstile
      WHERE passlog.turnstile_id = turnstile.id
        AND passlog.success = true
        AND passlog.successout = true
      GROUP BY passlog.kisi_id, passlog.isletme_id, turnstile.hall_id,
               (to_date(to_char(passlog.logtime, 'yyyyMMdd'::text), 'yyyyMMdd'::text))) x
GROUP BY x.isletme_id, x.hall_id, x.day
ORDER BY x.isletme_id, x.hall_id, x.day;

alter table passloghall
    owner to pgrootcmv;

